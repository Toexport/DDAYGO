//
//  LPDVideoPlayerController.h
//  LPDQuoteSystemImagesController
//
//  Created by Assuner on 2016/12/18.
//  Copyright © 2016年 Assuner. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LPDAssetModel;
@interface LPDVideoPlayerController : UIViewController

@property (nonatomic, strong) LPDAssetModel *model;

@end
